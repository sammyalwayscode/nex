import React from "react";

const page = () => {
  return (
    <div>
      <div>This is the Agent's Screen</div>
    </div>
  );
};

export default page;
