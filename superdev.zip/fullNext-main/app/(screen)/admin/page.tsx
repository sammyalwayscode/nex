import React from "react";

const page = () => {
  return (
    <div>
      <div>This is the Admin's Screen</div>
    </div>
  );
};

export default page;
